# Portfolio Intelligence — Free Data Fix

This version keeps the app free.

- Yahoo Finance / yfinance: prices, profile and valuation fallback
- SEC EDGAR company facts: revenue, net income and US filings
- No paid analyst-data API
- Analyst price-target section explicitly shows unavailable rather than blank/misleading data

This specifically improves coverage for US-listed names such as IBKR when Yahoo Finance returns incomplete fundamentals.
